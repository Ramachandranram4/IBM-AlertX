# Download the helper library from https://www.twilio.com/docs/python/install
import os
from twilio.rest import Client
from typing import Dict, Optional

def send_alert_call(message: str, to_number: str, from_number: Optional[str] = None) -> Dict:
    """
    Send an alert call using Twilio Voice API.
    
    Args:
        message (str): The message to be spoken during the call
        to_number (str): The phone number to call (in E.164 format)
        from_number (str, optional): The Twilio phone number to call from
        
    Returns:
        Dict: Call result information
        
    Raises:
        RuntimeError: If Twilio credentials are not configured
        ValueError: If required parameters are missing
    """
    # Get credentials from environment variables
    account_sid = os.environ.get("TWILIO_ACCOUNT_SID")
    auth_token = os.environ.get("TWILIO_AUTH_TOKEN")
    default_from_number = os.environ.get("TWILIO_FROM_NUMBER")
    
    if not account_sid or not auth_token:
        raise RuntimeError("Twilio credentials not configured. Please set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN environment variables.")
    
    if not message:
        raise ValueError("Message content is required")
    
    if not to_number:
        raise ValueError("Destination phone number is required")
    
    # Use provided from_number or fall back to environment variable
    caller_number = from_number or default_from_number
    if not caller_number:
        raise RuntimeError("Caller phone number not configured. Please set TWILIO_FROM_NUMBER environment variable or provide from_number parameter.")
    
    try:
        client = Client(account_sid, auth_token)
        
        # Create TwiML response with the message
        twiml_content = f"<Response><Say>{message}</Say></Response>"
        
        call = client.calls.create(
            twiml=twiml_content,
            to=to_number,
            from_=caller_number,
        )
        
        return {
            "status": "success",
            "call_sid": call.sid,
            "to": to_number,
            "from": caller_number,
            "message_preview": message[:100] + "..." if len(message) > 100 else message
        }
        
    except Exception as e:
        raise RuntimeError(f"Failed to place Twilio call: {str(e)}")

def validate_phone_number(phone_number: str) -> bool:
    """
    Basic validation for phone number format.
    
    Args:
        phone_number (str): Phone number to validate
        
    Returns:
        bool: True if format appears valid, False otherwise
    """
    if not phone_number:
        return False
    
    # Basic E.164 format check (starts with + and contains only digits)
    return phone_number.startswith('+') and phone_number[1:].isdigit() and len(phone_number) >= 10

def create_emergency_alert(incident_type: str, location: str, risk_level: str, recommendations: list) -> str:
    """
    Create a formatted emergency alert message.
    
    Args:
        incident_type (str): Type of incident detected
        location (str): Location of the incident
        risk_level (str): Risk assessment level
        recommendations (list): List of recommended actions
        
    Returns:
        str: Formatted alert message
    """
    message_parts = [
        "Hello, this is the AlertX Operations Agent speaking.",
        f"We have detected {incident_type} at {location}.",
        f"Risk assessment: {risk_level}."
    ]
    
    if recommendations:
        message_parts.append("Recommended immediate actions:")
        for rec in recommendations:
            message_parts.append(rec)
    
    message_parts.append("Please confirm if your team can respond immediately.")
    
    return " ".join(message_parts)

