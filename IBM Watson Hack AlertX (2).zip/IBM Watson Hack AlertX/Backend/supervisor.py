# supervisor.py
# from agents.agent1_vision import analyze_frame
# from agents.agent2_geo import get_surroundings
# from agents.agent3_reasoning import generate_recommendations
# from agents.agent4_caller import generate_call_content

# if __name__ == "__main__":
#     frame_path = "inputs/pic1.png"
#     location = {"lat": 12.9716, "lon": 77.5946}

#     vision_out = analyze_frame(frame_path)
#     geo_out = get_surroundings(location)
#     recs = generate_recommendations(vision_out, geo_out)
#     call_ctx = generate_call_content(recs,"Fire Department")

#     print("=== Final Call Context ===")
#     print(call_ctx)


# supervisor.py
from agents.agent1_vision import analyze_frame
from agents.agent2_geo import get_surroundings
from agents.agent3_reasoning import generate_recommendations
from agents.agent4_caller import generate_call_content, mock_place_call

import json

def run_workflow(frame_path: str, location: dict, authority: str = "Brigade Fire Dept"):
    print("→ Agent 1: Vision analysis")
    vision_out = analyze_frame(frame_path)

    print("→ Agent 2: Geo context")
    geo_out = get_surroundings(location)

    print("→ Agent 3: Recommendation reasoning")
    recs = generate_recommendations(vision_out, geo_out)

    # enrich recs with area name for caller convenience
    recs["area_name"] = location.get("area_name", "MG Road Junction")
    print("→ Agent 4: Generate calling script")
    call_ctx = generate_call_content(recs, authority)

    # For demo, we do not place a real call — return the call script and a simulated call result
    simulated_result = mock_place_call(call_ctx)

    return {
        "agent1": vision_out,
        "agent2": geo_out,
        "agent3": recs,
        "agent4_call_context": call_ctx,
        "agent4_simulated_call": simulated_result
    }

if __name__ == "__main__":
    demo_location = {"lat": 12.9716, "lon": 77.5946, "area_name": "MG Road Junction"}
    out = run_workflow("inputs/pic1.png", demo_location)
    print(json.dumps(out, indent=2))
