# agents/agent3_recommender.py
import os
import requests
from datetime import datetime
from typing import Dict, List
import json

WATSONX_API_KEY = os.getenv("WATSONX_API_KEY")
WATSONX_URL = os.getenv("WATSONX_URL")
WATSONX_LLM_DEPLOYMENT = os.getenv("WATSONX_LLM_DEPLOYMENT")  # e.g., granite-4 deployment id

def _mock_recommendations(vision_result: Dict, geo_result: Dict) -> Dict:
    return {
        "event_summary": vision_result["scene_description"],
        "risk_level": vision_result["risk_assessment"],
        "recommendations": [
            "Alert local disaster management team.",
            "Redirect traffic away from MG Road Junction.",
            f"Deploy rescue unit near {geo_result['nearby_places'][0]['name']} ({geo_result['nearby_places'][0]['distance_km']} km).",
            "Activate emergency drainage pumps and shut down nearby power sections if needed."
        ],
        "suggested_authorities": [
            "Brigade Fire Dept",
            "MG Road Police",
            "CityCare Hospital"
        ],
        "priority": "High",
        "generated_at": datetime.utcnow().isoformat() + "Z"
    }

def call_granite_llm(prompt: str) -> Dict:
    if not (WATSONX_API_KEY and WATSONX_URL and WATSONX_LLM_DEPLOYMENT):
        raise RuntimeError("watsonx llm creds not configured")
    # Basic /generation style call - adapt to your watsonx.ai API shape
    gen_url = f"{WATSONX_URL}/v1/deployments/{WATSONX_LLM_DEPLOYMENT}/generate"
    headers = {"Authorization": f"Bearer {WATSONX_API_KEY}", "Content-Type": "application/json"}
    payload = {"input": prompt, "max_tokens": 512}
    resp = requests.post(gen_url, headers=headers, json=payload, timeout=60)
    resp.raise_for_status()
    return resp.json()

def generate_recommendations(vision_result: Dict, geo_result: Dict) -> Dict:
    """
    Try to use a Granite LLM to produce recommendations, otherwise return mock.
    The prompt composes vision + geo context and asks for prioritized recommended actions.
    """
    try:
        if WATSONX_API_KEY and WATSONX_URL and WATSONX_LLM_DEPLOYMENT:
            prompt = f"""
You are an urban incident response advisor.
Scene: {vision_result['scene_description']}
Risk: {vision_result['risk_assessment']}
Nearby: {', '.join([p['name'] + ' ('+p['type']+')' for p in geo_result['nearby_places']])}

Produce a JSON object with:
- top_priority (High/Medium/Low)
- recommendations (list of short action sentences)
- suggested_authorities (list)
- short_executive_summary (2-3 sentences)
"""
            llm_resp = call_granite_llm(prompt)
            # adapt parsing to response format; we conservatively return mock if parsing fails
            # some Granite deployments return 'output' or 'generated_text' etc.
            text = ""
            if isinstance(llm_resp, dict):
                # Try a few keys
                text = llm_resp.get("output") or llm_resp.get("generated_text") or str(llm_resp)
            # naive parse attempt — if LLM returns JSON, try to load it
            try:
                parsed = json.loads(text)
                return parsed
            except Exception:
                # fallback to constructing a structured object from text
                return {"raw_llm_text": text, "generated_at": datetime.utcnow().isoformat() + "Z"}
    except Exception as e:
        print("LLM call skipped/failed:", e)

    return _mock_recommendations(vision_result, geo_result)
