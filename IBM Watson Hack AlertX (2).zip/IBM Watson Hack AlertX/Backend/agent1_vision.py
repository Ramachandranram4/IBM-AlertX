import os
import base64
import json
import requests
from datetime import datetime
from typing import Dict

WATSONX_API_KEY = os.getenv("WATSONX_API_KEY")
WATSONX_URL = os.getenv("WATSONX_URL")  # e.g. https://api.us-south.watsonx.ai
WATSONX_VISION_DEPLOYMENT = os.getenv("WATSONX_VISION_DEPLOYMENT")  # your vision deployment id

def call_granite_vision_bytes(image_bytes: bytes, filename="frame.jpg") -> Dict:
    """
    Call a watsonx.ai vision deployment infer endpoint.
    Adjust this function to match the exact API used by your instance.
    """
    if not (WATSONX_API_KEY and WATSONX_URL and WATSONX_VISION_DEPLOYMENT):
        raise RuntimeError("watsonx vision credentials not configured")

    infer_url = f"{WATSONX_URL}/v1/deployments/{WATSONX_VISION_DEPLOYMENT}/infer"
    headers = {"Authorization": f"Bearer {WATSONX_API_KEY}"}
    files = {"file": (filename, image_bytes, "application/octet-stream")}
    resp = requests.post(infer_url, headers=headers, files=files, timeout=60)
    resp.raise_for_status()
    return resp.json()

def analyze_frame(frame_path: str) -> Dict:
    """
    Main agent1 entrypoint for frame analysis.
    Requires proper environment variables to be set for Watson X AI.
    """
    if not os.path.exists(frame_path):
        raise FileNotFoundError(f"Frame file not found: {frame_path}")
    
    if not (WATSONX_API_KEY and WATSONX_URL and WATSONX_VISION_DEPLOYMENT):
        raise RuntimeError("Watson X AI credentials not configured. Please set environment variables.")
    
    try:
        with open(frame_path, "rb") as f:
            image_bytes = f.read()
        
        resp_json = call_granite_vision_bytes(image_bytes, filename=frame_path.split("/")[-1])
        
        # Parse response based on actual Granite Vision response schema
        preds = resp_json.get("predictions") or resp_json.get("outputs") or []
        objects = []
        
        for p in preds:
            label = p.get("label") or p.get("class") or p.get("name")
            conf = p.get("confidence") or p.get("score") or p.get("probability")
            if label:
                objects.append({"label": label, "confidence": conf})
        
        # Generate scene description and risk assessment
        scene_desc = " | ".join([o["label"] for o in objects]) or "Scene detected"
        risk = "Moderate"
        
        # Risk assessment logic
        if any("flood" in o["label"].lower() for o in objects):
            risk = "Severe"
        elif any(keyword in o["label"].lower() for o in objects for keyword in ["fire", "accident", "emergency"]):
            risk = "High"
        
        return {
            "frame": frame_path,
            "objects_detected": objects,
            "scene_description": f"Detected: {scene_desc}",
            "risk_assessment": risk,
            "event_category": "Unknown",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "raw_model_response": resp_json
        }
        
    except Exception as e:
        raise RuntimeError(f"Vision analysis failed: {str(e)}")