import cv2
import numpy as np
import os

# === CONFIGURATION ===
VIDEO_PATH = ""               # path to your video file
OUTPUT_DIR = "scenes"         # folder to save detected scene frames
FRAME_INTERVAL = 10           # analyze every 10th frame
THRESHOLD = 0.6               # histogram similarity threshold (lower → more sensitive)
# ======================

def detect_scene_changes(video_path, output_dir="scenes", frame_interval=10, threshold=0.6):
    """
    Detect scene changes in a video using histogram comparison.
    
    Args:
        video_path (str): Path to the input video file
        output_dir (str): Directory to save scene frames
        frame_interval (int): Process every Nth frame
        threshold (float): Similarity threshold for scene detection
    
    Returns:
        int: Number of scene changes detected
    """
    if not video_path:
        print("❌ Error: Please specify a video file path.")
        return 0
    
    if not os.path.exists(video_path):
        print(f"❌ Error: Video file '{video_path}' not found.")
        return 0

    # Create output folder if not exists
    os.makedirs(output_dir, exist_ok=True)

    cap = cv2.VideoCapture(video_path)
    prev_hist = None
    scene_changes = []
    frame_no = 0
    saved_count = 0

    if not cap.isOpened():
        print("❌ Error: Cannot open video file.")
        return 0

    print("🎥 Processing video... Please wait.")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Process every Nth frame to reduce computation
        if frame_no % frame_interval != 0:
            frame_no += 1
            continue

        # Convert frame to HSV color space
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Compute histogram (50 bins for H, 60 for S)
        hist = cv2.calcHist([hsv], [0, 1], None, [50, 60], [0, 180, 0, 256])
        hist = cv2.normalize(hist, hist).flatten()

        # Compare with previous histogram
        if prev_hist is not None:
            similarity = cv2.compareHist(prev_hist, hist, cv2.HISTCMP_CORREL)

            # If correlation drops below threshold → scene change detected
            if similarity < threshold:
                scene_changes.append((frame_no, similarity))
                saved_count += 1

                # Save current frame as image
                output_path = os.path.join(output_dir, f"scene_{saved_count:03d}.jpg")
                cv2.imwrite(output_path, frame)
                print(f"📸 Scene change detected at frame {frame_no}, similarity={similarity:.3f}")

        prev_hist = hist
        frame_no += 1

    cap.release()
    print(f"\n✅ Done! {saved_count} scene frames saved in '{output_dir}' folder.")
    return saved_count

if __name__ == "__main__":
    # Usage example - replace with your video path
    video_file = VIDEO_PATH
    if video_file:
        detect_scene_changes(video_file, OUTPUT_DIR, FRAME_INTERVAL, THRESHOLD)
    else:
        print("Please set VIDEO_PATH to your video file location.")
        print("\nUsage example:")
        print("VIDEO_PATH = 'path/to/your/video.mp4'")
        print("python scene_detection.py")