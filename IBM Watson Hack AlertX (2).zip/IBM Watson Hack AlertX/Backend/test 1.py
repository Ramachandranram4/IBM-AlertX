# supervisor.py
import json
import os
from typing import Dict, Optional
from agents.agent1_vision import analyze_frame
from agents.agent2_geo import get_surroundings
from agents.agent3_reasoning import generate_recommendations
from agents.agent4_caller import generate_call_content, place_call

def run_workflow(frame_path: str, location: Dict, authority: str = "Emergency Services") -> Dict:
    """
    Execute the complete emergency response workflow.
    
    Args:
        frame_path (str): Path to the image/frame to analyze
        location (Dict): Location data with lat/lon coordinates
        authority (str): Target authority for emergency call
        
    Returns:
        Dict: Complete workflow results from all agents
        
    Raises:
        ValueError: If required parameters are missing
        RuntimeError: If any agent fails to execute
    """
    if not frame_path or not os.path.exists(frame_path):
        raise ValueError(f"Invalid frame path: {frame_path}")
    
    if not location or not location.get("lat") or not location.get("lon"):
        raise ValueError("Location with lat/lon coordinates is required")
    
    if not authority:
        raise ValueError("Authority identifier is required")
    
    try:
        print("→ Agent 1: Vision analysis")
        vision_out = analyze_frame(frame_path)
        
        print("→ Agent 2: Geo context")
        geo_out = get_surroundings(location)
        
        print("→ Agent 3: Recommendation reasoning")
        recs = generate_recommendations(vision_out, geo_out)
        
        # Enrich recommendations with area information
        recs["area_name"] = location.get("area_name", "detected location")
        
        print("→ Agent 4: Generate calling script")
        call_ctx = generate_call_content(recs, authority)
        
        return {
            "agent1_vision": vision_out,
            "agent2_geo": geo_out,
            "agent3_recommendations": recs,
            "agent4_call_context": call_ctx,
            "workflow_status": "completed",
            "timestamp": vision_out.get("timestamp")
        }
        
    except Exception as e:
        raise RuntimeError(f"Workflow execution failed: {str(e)}")

def execute_emergency_call(call_context: Dict) -> Dict:
    """
    Execute the actual emergency call using the generated call context.
    
    Args:
        call_context (Dict): Call context from generate_call_content()
        
    Returns:
        Dict: Call execution result
    """
    try:
        return place_call(call_context)
    except Exception as e:
        raise RuntimeError(f"Emergency call execution failed: {str(e)}")

def validate_workflow_inputs(frame_path: str, location: Dict, authority: str) -> bool:
    """
    Validate all workflow inputs before execution.
    
    Args:
        frame_path (str): Path to image file
        location (Dict): Location data
        authority (str): Authority identifier
        
    Returns:
        bool: True if all inputs are valid
    """
    # Check frame path
    if not frame_path or not os.path.exists(frame_path):
        return False
    
    # Check location data
    if not location or not isinstance(location, dict):
        return False
    
    required_coords = ["lat", "lon"]
    if not all(coord in location for coord in required_coords):
        return False
    
    # Check authority
    if not authority or not isinstance(authority, str):
        return False
    
    return True

if __name__ == "__main__":
    # Example usage - requires actual implementation of agent3_reasoning
    # and proper environment configuration for all agents
    
    print("Emergency Response Workflow System")
    print("Requires proper configuration of all agent environment variables")
    print("See individual agent files for required credentials")
    
    # Uncomment and modify for actual usage:
    # demo_location = {"lat": 12.9716, "lon": 77.5946, "area_name": "MG Road Junction"}
    # try:
    #     workflow_result = run_workflow("inputs/pic1.png", demo_location, "Fire Department")
    #     print(json.dumps(workflow_result, indent=2))
    # except Exception as e:
    #     print(f"Workflow failed: {e}")