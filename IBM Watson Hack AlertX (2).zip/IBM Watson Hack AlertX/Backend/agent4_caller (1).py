# agents/agent4_caller.py
import os
from datetime import datetime
from typing import Dict, List

# If you later integrate Watson TTS or Twilio, configure API keys here.
TTS_PROVIDER = os.getenv("TTS_PROVIDER", "")  # 'watson_tts' or 'twilio' etc.

def _compose_script(recommendations: Dict, authority: str) -> Dict:
    # Compose a natural, human-sounding call script from the recommendations + context
    summary = recommendations.get("event_summary") or "An incident was detected."
    risk = recommendations.get("risk_level", "Moderate")
    recs = recommendations.get("recommendations", [])
    area = recommendations.get("area_name", "the affected area")
    lines = []
    lines.append(f"Hello, this is the AlertX Operations Assistant calling from City Control.")
    lines.append(f"We have detected {summary}")
    lines.append(f"Risk assessment: {risk}.")
    if recs:
        lines.append("Recommended immediate actions:")
        for r in recs:
            lines.append(f"- {r}")
    lines.append("Please confirm if your team can respond. We can share live visuals and precise coordinates.")
    lines.append("Thank you — we will continue to monitor and update you.")
    return {
        "to_authority": authority,
        "tone": "professional, calm, urgent" if risk in ["Severe","High"] else "informative",
        "script_lines": lines,
        "estimated_duration_sec": 40,
        "generated_at": datetime.utcnow().isoformat() + "Z"
    }

def generate_call_content(recommendations: Dict, authority: str) -> Dict:
    """
    Build the call content. This output is intended for:
    - displaying to the user for approval
    - feeding to a TTS + telephony system (Twilio / Orchestrate voice) after approval
    """
    # Simple logic: pick authority name; you can map to phone number later
    call_ctx = _compose_script(recommendations, authority)
    return call_ctx

def mock_place_call(call_ctx: Dict) -> Dict:
    """
    Simulated call execution (used for demo). Returns simulated call result.
    """
    return {
        "status": "simulated_call_placed",
        "to": call_ctx["to_authority"],
        "message_preview": "\n".join(call_ctx["script_lines"][:3]) + "...",
        "call_id": "SIM-" + datetime.utcnow().strftime("%Y%m%d%H%M%S"),
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }
