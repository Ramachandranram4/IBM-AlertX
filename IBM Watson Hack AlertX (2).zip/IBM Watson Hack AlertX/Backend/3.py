import requests
import base64
import os
from PIL import Image
from ibm_watsonx_ai import Credentials
from ibm_watsonx_ai.foundation_models import ModelInference

# Configuration - Replace with your actual credentials
WATSONX_APIKEY = ""  # Your Watson X API key
WATSONX_PROJECT_ID = ""  # Your Watson X project ID
URL = "https://us-south.ml.cloud.ibm.com"

def analyze_images_in_folder(folder_path, api_key, project_id, user_query="What is in this image?"):
    """
    Analyze all images in a folder using Watson X AI vision model.
    
    Args:
        folder_path (str): Path to folder containing images
        api_key (str): Watson X API key
        project_id (str): Watson X project ID
        user_query (str): Query to ask about each image
    
    Returns:
        list: Analysis results for each image
    """
    if not api_key or not project_id:
        print("❌ Error: Please provide Watson X API key and project ID.")
        return []
    
    if not os.path.exists(folder_path):
        print(f"❌ Error: Folder '{folder_path}' not found.")
        return []

    credentials = Credentials(
        url=URL,
        api_key=api_key
    )

    encoded_images = []
    image_filenames = []

    # Process all image files in the folder
    for filename in os.listdir(folder_path):
        if filename.lower().endswith((".png", ".jpg", ".jpeg")):
            image_path = os.path.join(folder_path, filename)
            try:
                with open(image_path, "rb") as img_file:
                    encoded_string = base64.b64encode(img_file.read()).decode("utf-8")
                    encoded_images.append(encoded_string)
                    image_filenames.append(filename)
            except Exception as e:
                print(f"⚠️ Warning: Could not process {filename}: {e}")

    if not encoded_images:
        print("❌ No valid images found in the folder.")
        return []

    def create_api_request_body(query, image):
        """Create the API request body for image analysis."""
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            "You are a Visual Identifier and Image Analyzer. "
                            "Analyze the given image carefully and answer the user's query. "
                            "Respond in **strict JSON format** as shown below (do not hallucinate extra fields). "
                            "Ensure the descriptions are concise and factual.\n\n"
                            "Example JSON output:\n"
                            "{\n"
                            '  "objects_detected": ["flooded road", "damaged electric pole", "stagnant water"],\n'
                            '  "scene_description": "Detected flooded street with vehicles partially submerged. Risk of electrocution and traffic blockage.",\n'
                            '  "risk_assessment": "Severe",\n'
                            '  "event_category": "Weather & Natural Hazards",\n'
                            '  "additional_notes": "Add any other relevant insights."\n'
                            "}\n\n"
                            f"User query: {query}"
                        ),
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{image}",
                        },
                    },
                ],
            }
        ]
        return messages

    model = ModelInference(
        model_id="meta-llama/llama-3-2-90b-vision-instruct",
        credentials=credentials,
        project_id=project_id,
        params={
            "max_tokens": 200
        }
    )

    results = []
    print(f"🔍 Analyzing {len(encoded_images)} images...")

    for i, (image, filename) in enumerate(zip(encoded_images, image_filenames)):
        try:
            print(f"\n📸 Processing: {filename}")
            messages = create_api_request_body(user_query, image)
            response = model.chat(messages=messages)
            
            analysis_result = {
                "filename": filename,
                "analysis": response['choices'][0]['message']['content']
            }
            results.append(analysis_result)
            
            print(f"✅ Analysis complete for {filename}")
            print(response['choices'][0]['message']['content'])
            
        except Exception as e:
            print(f"❌ Error analyzing {filename}: {e}")
            results.append({
                "filename": filename,
                "error": str(e)
            })

    return results

if __name__ == "__main__":
    # Configuration
    folder_path = "scenes"
    api_key = WATSONX_APIKEY
    project_id = WATSONX_PROJECT_ID
    
    if not api_key or not project_id:
        print("Please set your Watson X credentials:")
        print("WATSONX_APIKEY = 'your_api_key_here'")
        print("WATSONX_PROJECT_ID = 'your_project_id_here'")
    else:
        results = analyze_images_in_folder(folder_path, api_key, project_id)
        print(f"\n✅ Analysis complete! Processed {len(results)} images.")