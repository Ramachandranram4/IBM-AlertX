from flask import Flask, render_template, request, jsonify
import requests, math

app = Flask(__name__)

OVERPASS_URL = "https://overpass-api.de/api/interpreter"

# Haversine distance calculation (km)
def haversine_km(lat1, lon1, lat2, lon2):
    """Calculate the great circle distance between two points on earth in kilometers."""
    R = 6371.0  # Earth's radius in kilometers
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c

# Map categories to OpenStreetMap tag pairs
CATEGORY_MAP = {
    # Health & Emergency
    "general_hospital": [["amenity","hospital"]],
    "govt_hospital": [["amenity","hospital"]], 
    "veterinary": [["amenity","veterinary"]],
    "pharmacy": [["amenity","pharmacy"], ["shop","chemist"]],
    # Education
    "school": [["amenity","school"]],
    "college": [["amenity","college"]],
    "university": [["amenity","university"]],
    # Government & Civic
    "police": [["amenity","police"]],
    "fire_station": [["amenity","fire_station"]],
    "district_collectorate": [["office","government"], ["amenity","townhall"]],
    # Residential
    "old_age_home": [["social_facility","nursing_home"], ["amenity","nursing_home"]],
    "apartment": [["building","apartments"], ["building","residential"]],
    # Commercial
    "mall": [["shop","mall"], ["leisure","shopping_centre"]],
    "bank": [["amenity","bank"], ["amenity","atm"]],
    "fuel": [["amenity","fuel"]],
    "supermarket": [["shop","supermarket"]],
    # Transport
    "bus_station": [["amenity","bus_station"]],
    "metro": [["railway","station"], ["public_transport","station"]],
    "railway": [["railway","station"]],
    "airport": [["aeroway","aerodrome"]],
    # Public Gathering
    "theatre": [["amenity","theatre"]],
    "community_hall": [["amenity","community_centre"]],
    "stadium": [["leisure","stadium"]],
    "event_ground": [["leisure","stadium"], ["amenity","events"]],
    # Emergency Services
    "emergency_operations": [["office","emergency_operations"], ["emergency","control_center"], ["amenity","command_post"]]
}

def build_overpass_query(lat, lon, radius_m, tagpairs):
    """Build an Overpass API query for the given location and tag pairs."""
    parts = []
    for k, v in tagpairs:
        parts.append(f'node["{k}"="{v}"](around:{radius_m},{lat},{lon});')
        parts.append(f'way["{k}"="{v}"](around:{radius_m},{lat},{lon});')
        parts.append(f'relation["{k}"="{v}"](around:{radius_m},{lat},{lon});')
    inner = "\n".join(parts)
    query = f"[out:json][timeout:25];({inner});out center;"
    return query

@app.route("/")
def index():
    """Serve the main application page."""
    return render_template("index.html")

@app.route("/api/search", methods=["POST"])
def api_search():
    """
    Search for points of interest near a given location.
    
    Expected JSON payload:
    {
        "lat": float,
        "lon": float,
        "radius_m": int (optional, default 10000),
        "category": string,
        "max_results": int (optional, default 5)
    }
    """
    try:
        body = request.get_json()
        
        # Validate required parameters
        if not body:
            return jsonify({"error": "JSON payload required"}), 400
            
        lat = body.get("lat")
        lon = body.get("lon")
        category = body.get("category")
        
        if lat is None or lon is None:
            return jsonify({"error": "lat and lon are required"}), 400
            
        if not category:
            return jsonify({"error": "category is required"}), 400
            
        # Parse optional parameters
        try:
            lat = float(lat)
            lon = float(lon)
            radius_m = int(body.get("radius_m", 10000))
            max_results = int(body.get("max_results", 5))
        except (ValueError, TypeError):
            return jsonify({"error": "Invalid parameter types"}), 400
        
        # Validate coordinate ranges
        if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
            return jsonify({"error": "Invalid coordinates"}), 400
            
        # Get tag pairs for the category
        tagpairs = CATEGORY_MAP.get(category)
        if not tagpairs:
            # Fallback to generic amenity search
            tagpairs = [["amenity", category]]
            
        # Build and execute Overpass query
        query = build_overpass_query(lat, lon, radius_m, tagpairs)
        headers = {"User-Agent": "SmartCityHotspot/1.0"}
        
        resp = requests.post(OVERPASS_URL, data=query, headers=headers, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        
        # Process results
        results = []
        for element in data.get("elements", []):
            # Extract coordinates
            el_lat = element.get("lat") or (element.get("center") and element.get("center").get("lat"))
            el_lon = element.get("lon") or (element.get("center") and element.get("center").get("lon"))
            
            if el_lat is None or el_lon is None:
                continue
                
            # Extract name
            tags = element.get("tags", {})
            name = tags.get("name") or tags.get("operator") or "Unnamed Location"
            
            # Calculate distance
            distance = round(haversine_km(lat, lon, float(el_lat), float(el_lon)), 3)
            
            results.append({
                "name": name,
                "lat": float(el_lat),
                "lon": float(el_lon),
                "distance_km": distance,
                "tags": tags
            })
        
        # Sort by distance and limit results
        results = sorted(results, key=lambda x: x["distance_km"])[:max_results]
        
        return jsonify({
            "count": len(results),
            "results": results,
            "search_params": {
                "lat": lat,
                "lon": lon,
                "radius_m": radius_m,
                "category": category
            }
        })
        
    except requests.RequestException as e:
        return jsonify({"error": f"External API error: {str(e)}"}), 502
    except Exception as e:
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(405)
def method_not_allowed(error):
    """Handle 405 errors."""
    return jsonify({"error": "Method not allowed"}), 405

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5000)